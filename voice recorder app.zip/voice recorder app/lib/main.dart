import 'package:flutter/material.dart';

void main() {
  runApp(VoiceRecorderSimApp());
}

class VoiceRecorderSimApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Voice Recorder Sim',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        primaryColor: Color(0xFFB388EB), // Lavender color for the app
        colorScheme: ColorScheme.light(
          primary: Color(0xFFB388EB), // Primary color
          secondary: Color(0xFFD1C4E9), // Light lavender for accents
        ),
        scaffoldBackgroundColor: Color(0xFFF3E5F5), // Light lavender background
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFFB388EB), // Lavender color for the app bar
          titleTextStyle: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 20,
          ),
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: Color(0xFFB388EB), // Lavender color for FAB
        ),
        buttonTheme: ButtonThemeData(
          buttonColor: Color(0xFFB388EB), // Lavender for buttons
        ),
        textTheme: TextTheme(
          bodyLarge: TextStyle(color: Color(0xFF6200EE)), // Darker purple text
          bodyMedium: TextStyle(color: Color(0xFF6200EE)), // Darker purple text
          labelLarge: TextStyle(color: Colors.white), // Used for button text
        ),
        iconTheme: IconThemeData(
          color: Colors.white, // Icon color white for better visibility
        ),
      ),
      home: VoiceRecorderHome(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class VoiceRecorderHome extends StatefulWidget {
  @override
  _VoiceRecorderHomeState createState() => _VoiceRecorderHomeState();
}

class _VoiceRecorderHomeState extends State<VoiceRecorderHome> {
  List<String> recordings = [];

  void addFakeRecording() {
    setState(() {
      recordings.add('Recording_${recordings.length + 1}.mp3');
    });
  }

  void renameRecording(int index) {
    TextEditingController controller = TextEditingController(
      text: recordings[index],
    );
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Rename Recording'),
        content: TextField(controller: controller),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                recordings[index] = controller.text;
              });
              Navigator.pop(context);
            },
            child: Text("Rename"),
          ),
        ],
      ),
    );
  }

  void deleteRecording(int index) {
    setState(() {
      recordings.removeAt(index);
    });
  }

  void playRecording(String name) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("Simulated playback of $name")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Voice Recorder Sim')),
      floatingActionButton: FloatingActionButton(
        onPressed: addFakeRecording,
        child: Icon(Icons.mic),
      ),
      body: ListView.builder(
        itemCount: recordings.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
            color: Color(0xFFF1E6FF), // Soft lavender card color
            child: ListTile(
              title: Text(
                recordings[index],
                style: TextStyle(color: Color(0xFF6200EE)), // Dark purple text
              ),
              trailing: PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'play') playRecording(recordings[index]);
                  if (value == 'rename') renameRecording(index);
                  if (value == 'delete') deleteRecording(index);
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'play', child: Text("Play")),
                  PopupMenuItem(value: 'rename', child: Text("Rename")),
                  PopupMenuItem(value: 'delete', child: Text("Delete")),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
