import 'package:flutter/material.dart';

void main() {
  runApp(EmergencyContactApp());
}

class EmergencyContactApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Emergency Contact App',
      theme: ThemeData(primarySwatch: Colors.red),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<String> emergencyContacts = [];
  final TextEditingController contactController = TextEditingController();

  void addContact(String contact) {
    setState(() {
      emergencyContacts.add(contact);
    });
    contactController.clear();
  }

  void simulateDial(String number) {
    print("Dialing $number...");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Simulated call to $number")),
    );
  }

  void simulateSendSOS() {
    String fakeLocation =
        "https://www.google.com/maps/search/?api=1&query=12.9716,77.5946";
    for (var contact in emergencyContacts) {
      print("Sending SOS to $contact with location: $fakeLocation");
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Simulated SOS sent!")),
    );
  }

  void showAddContactDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Add Emergency Contact"),
        content: TextField(
          controller: contactController,
          decoration: InputDecoration(labelText: "Phone Number"),
          keyboardType: TextInputType.phone,
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context), child: Text("Cancel")),
          ElevatedButton(
              onPressed: () {
                if (contactController.text.isNotEmpty) {
                  addContact(contactController.text);
                  Navigator.pop(context);
                }
              },
              child: Text("Add"))
        ],
      ),
    );
  }

  Widget buildContactTile(String number) {
    return ListTile(
      title: Text(number),
      trailing: IconButton(
        icon: Icon(Icons.call, color: Colors.green),
        onPressed: () => simulateDial(number),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Emergency Contact App")),
      body: Column(
        children: [
          ElevatedButton.icon(
            icon: Icon(Icons.add),
            label: Text("Add Contact"),
            onPressed: showAddContactDialog,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: emergencyContacts.length,
              itemBuilder: (context, index) {
                return buildContactTile(emergencyContacts[index]);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              icon: Icon(Icons.warning),
              label: Text("Activate Emergency Mode"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                minimumSize: Size(double.infinity, 50),
              ),
              onPressed: simulateSendSOS,
            ),
          )
        ],
      ),
    );
  }
}
