</br>
### :gift_heart: Consider donating to show your appreciation
[Become a Github Sponsor](https://github.com/sponsors/mateusz-bak)
[Give a one time donation](https://www.buymeacoffee.com/mateuszbak)
</br>
#### [Join our community on Matrix.org](https://matrix.to/#/#openreads:matrix.org) to be involved in app's development.