export 'locale_delegate_nynorsk.dart';
