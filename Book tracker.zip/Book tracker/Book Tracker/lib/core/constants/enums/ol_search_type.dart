enum OLSearchType {
  general,
  title,
  author,
  isbn,
  openlibraryId,
}
