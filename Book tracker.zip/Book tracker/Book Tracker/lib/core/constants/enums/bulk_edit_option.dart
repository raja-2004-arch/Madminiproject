enum BulkEditOption {
  format,
  author,
  delete,
}
