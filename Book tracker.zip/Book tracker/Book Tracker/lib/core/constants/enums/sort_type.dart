enum SortType {
  byTitle,
  byAuthor,
  byRating,
  byPages,
  byStartDate,
  byFinishDate,
  byPublicationYear,
  byDateAdded,
  byDateModified,
}
