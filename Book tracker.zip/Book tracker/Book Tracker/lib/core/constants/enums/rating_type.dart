enum RatingType {
  bar,
  number,
}
