class BookReadStat {
  int? year;
  List<int> values;

  BookReadStat({
    this.year,
    required this.values,
  });
}
