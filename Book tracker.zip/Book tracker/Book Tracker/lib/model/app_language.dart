import 'dart:ui';

class AppLanguage {
  String fullName;
  Locale locale;

  AppLanguage(
    this.fullName,
    this.locale,
  );
}
