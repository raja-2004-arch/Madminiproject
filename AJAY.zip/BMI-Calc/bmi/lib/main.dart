import 'package:flutter/material.dart';

void main() {
  runApp(BMICalculatorApp());
}

class BMICalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BMI Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSwatch().copyWith(
          primary: Colors.deepPurple,
          secondary: Colors.deepPurpleAccent,
        ),
      ),
      home: BMICalculatorScreen(),
    );
  }
}

class BMICalculatorScreen extends StatefulWidget {
  @override
  _BMICalculatorScreenState createState() => _BMICalculatorScreenState();
}

class _BMICalculatorScreenState extends State<BMICalculatorScreen> {
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();

  double? _bmi;
  String _category = "";
  String _advice = "";
  bool _showResult = false;
  Color _categoryColor = Colors.black;

  void _calculateBMI() {
    final double? weight = double.tryParse(_weightController.text);
    final double? heightCm = double.tryParse(_heightController.text);

    if (weight == null || heightCm == null || weight <= 0 || heightCm <= 0) {
      setState(() {
        _bmi = null;
        _category = '';
        _advice = '⚠️ Please enter valid values for weight and height.';
        _showResult = false;
      });
      return;
    }

    double heightM = heightCm / 100;
    double bmi = weight / (heightM * heightM);

    setState(() {
      _bmi = bmi;
      _showResult = true;

      if (bmi < 18.5) {
        _category = "Underweight";
        _categoryColor = Colors.blue;
        _advice =
            "• Eat a nutritious, calorie-dense diet\n• Include healthy fats like avocados, nuts, and seeds\n• Drink high-calorie shakes or smoothies\n• Consider strength training\n• Consult a dietitian for guidance";
      } else if (bmi < 24.9) {
        _category = "Normal";
        _categoryColor = Colors.green;
        _advice =
            "• Great job maintaining a healthy weight!\n• Keep following a balanced diet\n• Continue regular exercise\n• Monitor your weight regularly";
      } else if (bmi < 29.9) {
        _category = "Overweight";
        _categoryColor = Colors.orange;
        _advice =
            "• Try to incorporate more physical activity\n• Manage portion sizes\n• Focus on nutrient-rich foods\n• Seek personalized tips from a dietitian";
      } else {
        _category = "Obese";
        _categoryColor = Colors.red;
        _advice =
            "• Consult a healthcare provider for a tailored weight-loss plan\n• Combine diet changes with exercise\n• Focus on nutrient-dense foods\n• Seek support groups or professionals";
      }
    });
  }

  void _resetForm() {
    _weightController.clear();
    _heightController.clear();
    setState(() {
      _bmi = null;
      _category = '';
      _advice = '';
      _showResult = false;
      _categoryColor = Colors.black;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade50,
      appBar: AppBar(title: Text('BMI Calculator'), centerTitle: true),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            if (!_showResult) ...[
              TextField(
                controller: _weightController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Weight (kg)',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 15),
              TextField(
                controller: _heightController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Height (cm)',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 25),
              ElevatedButton(
                onPressed: _calculateBMI,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
                child: Text('Calculate BMI', style: TextStyle(fontSize: 18)),
              ),
            ] else ...[
              Card(
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                margin: EdgeInsets.symmetric(vertical: 20),
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text(
                        'Your BMI: ${_bmi!.toStringAsFixed(2)}',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Category: $_category',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: _categoryColor,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        _advice,
                        style: TextStyle(fontSize: 16),
                        textAlign: TextAlign.left,
                      ),
                    ],
                  ),
                ),
              ),
              ElevatedButton.icon(
                onPressed: _resetForm,
                icon: Icon(Icons.refresh),
                label: Text('Find Next', style: TextStyle(fontSize: 18)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurpleAccent,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
