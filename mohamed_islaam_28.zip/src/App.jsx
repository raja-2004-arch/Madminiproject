import { View, Text, Alert } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import React, { useEffect, useState } from 'react'
import { MMKV } from 'react-native-mmkv';
import Welcome from './components/Welcome';
import LandingPage from './components/LandingPage';

const Stack = createStackNavigator();
const store = new MMKV();
const App = () => {
  const [isFirst, setIsFirst] = useState(store.getBoolean('first') ?? true);
  const [transactionLists, setTransactionLists] = useState([]);
  const [enter, setEnter] = useState(0);
  const [cat, setCat] = useState('');
  const [des, setDes] = useState('');
  const [typ, setTyp] = useState('');
  const [tim, setTim] = useState('');
  const [profile, setProfile] = useState(store.getString('profile') ?? 'https://cdn-icons-png.flaticon.com/512/10337/10337609.png');
  const [uname, setUname] = useState(store.getString('uname') ?? 'Guest');

  function notFirst() {
    store.set('first', false);
    setIsFirst(false);
  }
  useEffect(() => {
    render();
  }, [])

  async function render() {
    try {
      let list = store.getString('transaction_lists')
      setTransactionLists((JSON.parse(list)).reverse());
    }
    catch (err) {
      setTransactionLists([]);
      setTimeout(render(), 10000)
    }
  }

  async function handleAdd() {
    let maxId = transactionLists.length > 0
      ? Math.max(...transactionLists.map(item => Number(item.id)))
      : 0;

    let id = maxId + 1;
    let newData = {
      id,
      type: typ,
      amount: enter,
      category: cat,
      note: des,
      date: tim
    };
    let newList = [newData, ...transactionLists];
    setTransactionLists(newList);
    store.set('transaction_lists', JSON.stringify(newList));
  }


  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={isFirst ? 'welcome' : 'hp'} screenOptions={{ headerShown: false }}>
        <Stack.Screen name="welcome">
          {prev => <Welcome {...prev} notFirst={notFirst} />}
        </Stack.Screen>
        <Stack.Screen name="hp">
          {prev => (
            <LandingPage
              {...prev}
              transactionLists={transactionLists}
              enter={enter}
              setEnter={setEnter}
              cat={cat}
              setCat={setCat}
              des={des}
              setDes={setDes}
              typ={typ}
              setTyp={setTyp}
              tim={tim}
              setTim={setTim}
              handleAdd={handleAdd}
              profile={profile}
              setProfile={setProfile}
              uname={uname}
              setUname={setUname}
            />
          )}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  )
}

export default App;