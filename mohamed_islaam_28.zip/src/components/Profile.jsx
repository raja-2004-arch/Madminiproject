import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import { MMKV } from 'react-native-mmkv';
import ImagePicker from 'react-native-image-crop-picker';

const store = new MMKV();

const Profile = ({ profile, setProfile, uname, setUname }) => {
  const [nameEdit, setNameEdit] = useState(false);
  const [nameCont, setNameCont] = useState('');
  const [quote, setQuote] = useState('');

  useEffect(() => {
    fetch("https://api.quotable.io/random?tags=money|business|success")
      .then(res => res.json())
      .then(data => setQuote(data.content))
      .catch(() => setQuote("Stay consistent, results will follow."));
  }, []);

  function handleGallery() {
    ImagePicker.openPicker({
      cropping: true,
      width: 80,
      height: 80
    }).then((img) => {
      setProfile(img.path);
      store.set('profile', img.path);
    });
  }

  function handleName() {
    if (nameCont.trim() !== '') {
      setUname(nameCont);
      store.set('uname', nameCont);
    }
    setNameEdit(false);
    setNameCont('');
  }

  return (
    <View style={{ flex: 1, padding: 20, backgroundColor: '#FEF6E6' }}>
      <Text style={styles.title}>Profile</Text>

      {/* Profile Section */}
      <View style={styles.profileContainer}>
        <TouchableOpacity onPress={handleGallery}>
          <Image source={{ uri: profile }} style={styles.avatar} />
        </TouchableOpacity>

        {!nameEdit ? (
          <Text style={styles.username}>{uname}</Text>
        ) : (
          <TextInput
            value={nameCont}
            onChangeText={setNameCont}
            style={styles.input}
            placeholder="Enter your name"
          />
        )}

        {!nameEdit ? (
          <TouchableOpacity style={styles.editBtn} onPress={() => setNameEdit(true)}>
            <Text style={styles.editText}>Edit name</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <TouchableOpacity style={styles.confirmBtn} onPress={handleName}>
              <Text style={styles.editText}>Confirm</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setNameEdit(false)}>
              <Text style={styles.editText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Quote Section */}
      <View style={styles.quoteBox}>
        <Text style={styles.quote}>{quote}</Text>
      </View>
    </View>
  );
};

export default Profile;
const styles = StyleSheet.create({
  title: {
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  profileContainer: {
    marginTop: 30,
    alignItems: 'center',
    gap: 15,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 100,
    borderWidth: 2,
    borderColor: '#4EC9B0',
  },
  username: {
    fontSize: 22,
    fontWeight: '900',
  },
  input: {
    borderWidth: 1,
    borderColor: '#aaa',
    padding: 8,
    borderRadius: 8,
    width: 180,
    textAlign: 'center',
    backgroundColor: '#fff',
  },
  editBtn: {
    backgroundColor: '#129575',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
  },
  confirmBtn: {
    backgroundColor: '#129575',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
  },
  cancelBtn: {
    backgroundColor: '#D9534F',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
  },
  editText: {
    color: 'white',
    fontWeight: 'bold',
  },
  quoteBox: {
    marginTop: 40,
    padding: 20,
    backgroundColor: '#EEE5FF',
    borderRadius: 12,
  },
  quote: {
    fontSize: 16,
    fontStyle: 'italic',
    textAlign: 'center',
    color: '#333',
  },
});
