pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    plugins {
        id("org.jetbrains.kotlin.android") version "1.9.22"
        id("com.android.application") version "8.0.0"
        id("org.jetbrains.kotlin.plugin.compose") version "1.5.11" // ✅ Add this
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "miniproject"
include(":app")
