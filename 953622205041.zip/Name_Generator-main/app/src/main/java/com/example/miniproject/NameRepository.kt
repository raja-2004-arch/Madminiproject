package com.example.miniproject

object NameRepository {
    val names = listOf(
        Name("Aarav", "Male", "Indian"),
        Name("Sakura", "Female", "Japanese"),
        Name("John", "Male", "American"),
        Name("Mei", "Female", "Japanese"),
        Name("Priya", "Female", "Indian"),
        Name("Alex", "Neutral", "American"),
        Name("Hiro", "Male", "Japanese"),
        Name("Kiran", "Neutral", "Indian"),
        Name("Emily", "Female", "American"),
        Name("Sam", "Neutral", "American")
    )
}
