package com.example.miniproject

object NameGenerator {
    fun generate(gender: String, culture: String): Name? {
        val filtered = NameRepository.names.filter {
            (gender == "Any" || it.gender.equals(gender, true)) &&
                    (culture == "Any" || it.culture.equals(culture, true))
        }
        return if (filtered.isNotEmpty()) filtered.random() else null
    }
}
