package com.example.miniproject.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.miniproject.NameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavController, nameViewModel: NameViewModel) {

    var name by remember { mutableStateOf("Generated Name") }
    var selectedCategory by remember { mutableStateOf("all") }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Name Generator", fontSize = 22.sp) },
                colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = Color(0xFF6200EE), // Purple Color
                    titleContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .background(Color(0xFFF1F1F1)), // Light background
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Category Buttons
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryButton(text = "Boy", selected = selectedCategory == "boy") {
                    selectedCategory = "boy"
                }
                CategoryButton(text = "Girl", selected = selectedCategory == "girl") {
                    selectedCategory = "girl"
                }
                CategoryButton(text = "All", selected = selectedCategory == "all") {
                    selectedCategory = "all"
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Name Display Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(8.dp),
                modifier = Modifier.padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = name,
                        fontSize = 28.sp,
                        color = Color.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            ActionButton(text = "Generate Name") {
                name = generateRandomName(selectedCategory)
            }

            Spacer(modifier = Modifier.height(12.dp))

            ActionButton(text = "Add to Favorites") {
                nameViewModel.addFavorite(name)
            }

            Spacer(modifier = Modifier.height(12.dp))

            ActionButton(text = "View Favorites") {
                navController.navigate("favorites")
            }

            Spacer(modifier = Modifier.height(12.dp))

            ActionButton(text = "Share Name") {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, "Check out this name: $name")
                    type = "text/plain"
                }
                val shareIntent = Intent.createChooser(sendIntent, null)
                context.startActivity(shareIntent)
            }
        }
    }
}

@Composable
fun CategoryButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Color(0xFF6200EE) else Color(0xFFBB86FC),
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(50),
        modifier = Modifier.height(40.dp)
    ) {
        Text(text)
    }
}

@Composable
fun ActionButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(50.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF6200EE),
            contentColor = Color.White
        )
    ) {
        Text(text, fontSize = 18.sp)
    }
}
// Your MainScreen code above 👆

// 🔥 Add this after everything at the bottom
fun generateRandomName(category: String): String {
    val boyNames = listOf("Aarav", "Arjun", "Kiran", "Rohan", "Vivaan", "Raja", "Ajay", "Mathavan", "Vairam")
    val girlNames = listOf("Anaya", "Diya", "Meera", "Riya", "Zoya", "Alisha", "Abi", "Divya", "Selvi")

    return when (category) {
        "boy" -> boyNames.random()
        "girl" -> girlNames.random()
        else -> (boyNames + girlNames).random()
    }
}
