package com.example.miniproject

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Name(
    val name: String,
    val gender: String,
    val culture: String
) : Parcelable
