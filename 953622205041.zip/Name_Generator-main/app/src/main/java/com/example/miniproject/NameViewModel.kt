package com.example.miniproject

import androidx.lifecycle.ViewModel
import androidx.compose.runtime.mutableStateListOf

class NameViewModel : ViewModel() {
    // Holds the list of favorite names
    private val _favoriteNames = mutableStateListOf<String>()
    val favoriteNames: List<String> = _favoriteNames

    // Add a name to the favorites list
    fun addFavorite(name: String) {
        _favoriteNames.add(name)
    }
}
