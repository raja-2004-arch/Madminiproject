package com.example.miniproject

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.lifecycle.viewmodel.compose.viewModel // ✅ Import this
import com.example.miniproject.ui.MainScreen
import com.example.miniproject.FavoritesScreen

@Composable
fun AppNavigation(navController: NavHostController) {
    val nameViewModel: NameViewModel = viewModel() // ✅ Create instance

    NavHost(navController = navController, startDestination = "main") {
        composable("main") {
            MainScreen(navController = navController, nameViewModel = nameViewModel)
        }
        composable("favorites") {
            FavoritesScreen(navController = navController, nameViewModel = nameViewModel)
        }
    }
}
