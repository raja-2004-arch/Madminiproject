package com.example.miniproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import com.example.miniproject.ui.theme.MiniProjectTheme
import com.example.miniproject.Name // adjust if Name is elsewhere

class FavoritesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val favorites = intent.getParcelableArrayListExtra<Name>("favorites") ?: arrayListOf()

        setContent {
            MiniProjectTheme {
                FavoritesScreenContent(favorites)
            }
        }
    }
}

@Composable
fun FavoritesScreenContent(favorites: List<Name>) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Your Favorites", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))
            if (favorites.isEmpty()) {
                Text("No favorites found.", style = MaterialTheme.typography.bodyLarge)
            } else {
                favorites.forEach { name ->
                    Text(name.name, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
