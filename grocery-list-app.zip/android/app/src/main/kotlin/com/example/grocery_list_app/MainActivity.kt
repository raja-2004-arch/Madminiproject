package com.example.grocery_list_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
